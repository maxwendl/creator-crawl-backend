# Creator Crawl — Backend Deployment Guide

This guide walks you through deploying the Node.js backend to **Google Cloud Run** and setting up the database.

## Prerequisites

- Google Cloud account (with Firestore set up from Phase 1)
- Google Cloud CLI (`gcloud` command) installed ([install here](https://cloud.google.com/sdk/docs/install))
- A CreatorCrawl API key
- Docker (optional; Cloud Build can handle it)

## Step 1: Prepare environment variables

1. In the backend folder, create `.env` from `.env.example`:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your actual values:
   ```
   JWT_SECRET=some-random-long-secret-key-here
   SHARED_EMAIL=user@example.com
   SHARED_PASSWORD=your-password-here
   CREATORC_API_KEY=sk_live_your_actual_key_here
   HF_API_KEY=hf_your_huggingface_key_here
   GOOGLE_PROJECT_ID=your-gcp-project-id
   ```

## Step 2: Deploy to Cloud Run

### Option A: Using Cloud Console (easiest)

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. **Cloud Run** (search top) → **Create Service**
3. **Deploy one revision from an existing image**? No. Click **Set up with Cloud Build** or **Continuously deploy**.
4. Connect your GitHub repo (or upload the code manually):
   - Source: GitHub repo with the backend code
   - Build type: Dockerfile
   - Region: choose nearest (e.g., europe-west1)
5. Environment variables: Add your `.env` values as secrets:
   - Click **Runtime settings** → **Secrets**
   - Add each variable (JWT_SECRET, SHARED_PASSWORD, CREATORC_API_KEY, etc.)
6. Click **Create**

Cloud Run will build and deploy automatically.

### Option B: Using gcloud CLI (faster if you prefer terminal)

```bash
# Log in
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Deploy
gcloud run deploy creator-crawl-backend \
  --source . \
  --platform managed \
  --region europe-west1 \
  --allow-unauthenticated \
  --set-env-vars="JWT_SECRET=your-secret,SHARED_EMAIL=user@example.com,SHARED_PASSWORD=password,CREATORC_API_KEY=sk_live_...,HF_API_KEY=hf_..." \
  --memory 512Mi \
  --timeout 3600
```

Cloud Run will output your service URL, e.g.:
```
Service URL: https://creator-crawl-backend-xxxxx.run.app
```

## Step 3: Grant Cloud Run permission to Firestore

Cloud Run needs permission to write to Firestore. The default service account should work, but to be sure:

1. Go to **IAM & Admin** → **Service Accounts**
2. Find the default Cloud Run service account (looks like `xxx@appspot.gserviceaccount.com`)
3. Click it → **Roles** → **Grant roles**
4. Add role: **Cloud Datastore User**

## Step 4: Update your frontend

In the frontend (the browser app), Settings (⚙) → Backend URL:
```
https://creator-crawl-backend-xxxxx.run.app
```

(Replace with your actual Cloud Run URL)

## Step 5: Test

1. Open the frontend in your browser
2. Log in with your SHARED_EMAIL and SHARED_PASSWORD
3. Try a crawl — you should see data fetched and saved to Firestore
4. Check Firestore console to verify reels are being saved

## Troubleshooting

### 401 Unauthorized from backend
- Check JWT_SECRET is the same in backend and frontend token validation
- Make sure your login credentials match SHARED_EMAIL and SHARED_PASSWORD

### Can't write to Firestore
- Verify Cloud Run service account has **Cloud Datastore User** role
- Check Firestore rules allow writes (should be default in production mode)

### CreatorCrawl API 401
- Verify CREATORC_API_KEY is correct and prefixed with `sk_live_`
- Check the key hasn't been revoked in the CreatorCrawl dashboard

### Cold start takes 10+ seconds
- Normal for first request after deploy. Subsequent requests are faster.
- Can reduce by keeping requests coming, or upgrading to 2 vCPUs (costs more)

## Scaling & cost

- **Free tier**: 2 million requests/month, enough for most solo/small-team use
- **Cost after free tier**: ~$0.40 per million requests
- Monitor in Cloud Run dashboard → **Metrics**

## Next: Automated crawling

Once the backend is stable, we'll set up **Cloud Scheduler** to:
1. Run a cron job (e.g., every hour)
2. Check user schedules in Firestore
3. Trigger crawls automatically for handles that need it
4. Save results to database

This goes in Phase 3.
